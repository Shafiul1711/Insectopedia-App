import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:camera/camera.dart';
import 'package:image_picker/image_picker.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:image/image.dart' as img;

import 'pipeline_engine.dart';

// ─── Entry point ─────────────────────────────────────────────────────────────

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  final cameras = await availableCameras();
  runApp(ProviderScope(child: GrowLivApp(cameras: cameras)));
}

// ─── Theme ───────────────────────────────────────────────────────────────────

class T {
  static const bg        = Color(0xFF0B1512);
  static const surface   = Color(0xFF122018);
  static const elevated  = Color(0xFF1B2E22);
  static const accent    = Color(0xFF4AE285);
  static const accentDim = Color(0xFF2D7A50);
  static const warn      = Color(0xFFFFC145);
  static const danger    = Color(0xFFFF5E5E);
  static const textPri   = Color(0xFFE8F5EE);
  static const textSec   = Color(0xFF7AB090);
  static const border    = Color(0xFF243D2D);

  static ThemeData get theme => ThemeData(
    brightness: Brightness.dark,
    scaffoldBackgroundColor: bg,
    colorScheme: const ColorScheme.dark(
      surface: surface, primary: accent, error: danger),
    textTheme: TextTheme(
      displayLarge: GoogleFonts.spaceGrotesk(
          fontSize: 28, fontWeight: FontWeight.w700, color: textPri, letterSpacing: -0.5),
      titleLarge:  GoogleFonts.spaceGrotesk(
          fontSize: 20, fontWeight: FontWeight.w600, color: textPri),
      titleMedium: GoogleFonts.spaceGrotesk(
          fontSize: 16, fontWeight: FontWeight.w500, color: textPri),
      bodyMedium:  GoogleFonts.inter(fontSize: 14, color: textSec),
      bodySmall:   GoogleFonts.inter(fontSize: 12, color: textSec),
      labelLarge:  GoogleFonts.spaceGrotesk(
          fontSize: 14, fontWeight: FontWeight.w600, color: bg),
    ),
  );
}

// ─── State ───────────────────────────────────────────────────────────────────

enum AppStatus { idle, loading, running, done, error }

class PState {
  final AppStatus status;
  final String? imagePath;
  final PipelineResult? result;
  final String? error;
  final String msg;
  const PState({this.status=AppStatus.idle, this.imagePath,
    this.result, this.error, this.msg=''});
  PState copyWith({AppStatus? status, String? imagePath,
    PipelineResult? result, String? error, String? msg}) => PState(
    status: status ?? this.status, imagePath: imagePath ?? this.imagePath,
    result: result ?? this.result, error: error ?? this.error,
    msg: msg ?? this.msg);
}

class PipelineNotifier extends Notifier<PState> {
  final _pipeline = GrowLivPipeline();
  bool _ready = false;

  @override
  PState build() => const PState();

  Future<void> analyze(String path) async {
    try {
      state = state.copyWith(status: AppStatus.loading, imagePath: path,
          result: null, error: null, msg: 'Loading models…');
      if (!_ready) {
        await _pipeline.loadModels();
        _ready = true;
      }
      state = state.copyWith(status: AppStatus.running, msg: 'Running detection…');
      final bytes   = await File(path).readAsBytes();
      final decoded = img.decodeImage(bytes);
      if (decoded == null) throw Exception('Could not decode image');
      final result  = await _pipeline.run(decoded);
      state = state.copyWith(status: AppStatus.done, result: result, msg: '');
    } catch (e) {
      state = state.copyWith(status: AppStatus.error, error: e.toString());
    }
  }

  void reset() => state = const PState();
}

final pipelineProvider = NotifierProvider<PipelineNotifier, PState>(
    PipelineNotifier.new);

// ─── Root app ─────────────────────────────────────────────────────────────────

class GrowLivApp extends StatelessWidget {
  final List<CameraDescription> cameras;
  const GrowLivApp({super.key, required this.cameras});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'Insectopedia', debugShowCheckedModeBanner: false,
    theme: T.theme, home: HomeScreen(cameras: cameras));
}

// ─── Home screen ─────────────────────────────────────────────────────────────

class HomeScreen extends ConsumerStatefulWidget {
  final List<CameraDescription> cameras;
  const HomeScreen({super.key, required this.cameras});
  @override
  ConsumerState<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends ConsumerState<HomeScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _pulse;

  @override
  void initState() {
    super.initState();
    _pulse = AnimationController(vsync: this,
        duration: const Duration(milliseconds: 1800))..repeat(reverse: true);
  }

  @override
  void dispose() { _pulse.dispose(); super.dispose(); }

  Future<void> _gallery() async {
    final f = await ImagePicker().pickImage(
        source: ImageSource.gallery, imageQuality: 90,
        maxWidth: 2048, maxHeight: 2048);
    if (f != null) ref.read(pipelineProvider.notifier).analyze(f.path);
  }

  Future<void> _camera() async {
    if (widget.cameras.isEmpty) return;
    final path = await Navigator.push<String>(context,
        MaterialPageRoute(builder: (_) =>
            CameraCapturePage(cameras: widget.cameras)));
    if (path != null) ref.read(pipelineProvider.notifier).analyze(path);
  }

  @override
  Widget build(BuildContext context) {
    final ps = ref.watch(pipelineProvider);
    return Scaffold(
      backgroundColor: T.bg,
      body: SafeArea(child: ps.status == AppStatus.done && ps.result != null
          ? ResultPage(imagePath: ps.imagePath!, result: ps.result!,
              onReset: () => ref.read(pipelineProvider.notifier).reset())
          : _body(ps)),
    );
  }

  Widget _body(PState ps) => Column(children: [
    Padding(padding: const EdgeInsets.fromLTRB(24,24,24,0),
      child: Row(children: [
        _Dot(controller: _pulse), const SizedBox(width: 10),
        Text('Insectopedia', style: T.theme.textTheme.displayLarge),
        const Spacer(),
        IconButton(icon: const Icon(Icons.tune_rounded, color: T.textSec),
          onPressed: () => Navigator.push(context,
              MaterialPageRoute(builder: (_) => const SettingsPage()))),
      ])),
    const SizedBox(height: 4),
    Padding(padding: const EdgeInsets.symmetric(horizontal: 24),
      child: Text('On-device pest identification',
          style: T.theme.textTheme.bodyMedium)),
    const Spacer(),
    switch (ps.status) {
      AppStatus.idle    => _Idle(onCamera: _camera, onGallery: _gallery),
      AppStatus.loading ||
      AppStatus.running => _Loading(msg: ps.msg),
      AppStatus.error   => _Error(msg: ps.error ?? '',
          onRetry: () => ref.read(pipelineProvider.notifier).reset()),
      _                 => const SizedBox.shrink(),
    },
    const Spacer(),
    const SizedBox(height: 24),
  ]);
}

// ─── Idle / Loading / Error heroes ───────────────────────────────────────────

class _Idle extends StatelessWidget {
  final VoidCallback onCamera, onGallery;
  const _Idle({required this.onCamera, required this.onGallery});
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.symmetric(horizontal: 32),
    child: Column(children: [
      SizedBox(width: 180, height: 180,
          child: CustomPaint(painter: _RingPainter())),
      const SizedBox(height: 32),
      Text('Scan a pest', style: T.theme.textTheme.displayLarge),
      const SizedBox(height: 8),
      Text('Point your camera at an insect or upload a photo.\n'
           'Runs entirely on your device.',
          textAlign: TextAlign.center, style: T.theme.textTheme.bodyMedium),
      const SizedBox(height: 36),
      Row(children: [
        Expanded(child: _PrimaryBtn(icon: Icons.camera_alt_rounded,
            label: 'Camera', onTap: onCamera)),
        const SizedBox(width: 12),
        Expanded(child: _SecondaryBtn(icon: Icons.photo_library_rounded,
            label: 'Gallery', onTap: onGallery)),
      ]),
    ]),
  );
}

class _Loading extends StatelessWidget {
  final String msg;
  const _Loading({required this.msg});
  @override
  Widget build(BuildContext context) => Column(children: [
    const SizedBox(width: 64, height: 64,
        child: CircularProgressIndicator(color: T.accent, strokeWidth: 3)),
    const SizedBox(height: 20),
    Text(msg.isEmpty ? 'Analysing…' : msg, style: T.theme.textTheme.titleMedium),
    const SizedBox(height: 6),
    Text('All inference is on-device', style: T.theme.textTheme.bodySmall),
  ]);
}

class _Error extends StatelessWidget {
  final String msg; final VoidCallback onRetry;
  const _Error({required this.msg, required this.onRetry});
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.symmetric(horizontal: 32),
    child: Column(children: [
      const Icon(Icons.warning_amber_rounded, color: T.danger, size: 56),
      const SizedBox(height: 12),
      Text('Analysis failed',
          style: T.theme.textTheme.titleLarge!.copyWith(color: T.danger)),
      const SizedBox(height: 8),
      Text(msg, textAlign: TextAlign.center, style: T.theme.textTheme.bodyMedium),
      const SizedBox(height: 28),
      _PrimaryBtn(icon: Icons.refresh_rounded, label: 'Try Again', onTap: onRetry),
    ]),
  );
}

// ─── Result page ─────────────────────────────────────────────────────────────

class ResultPage extends StatelessWidget {
  final String imagePath;
  final PipelineResult result;
  final VoidCallback onReset;
  const ResultPage({super.key, required this.imagePath,
      required this.result, required this.onReset});

  Color get _confColor {
    if (result.joint >= 0.7) return T.accent;
    if (result.joint >= 0.4) return T.warn;
    return T.danger;
  }

  String get _display => result.predSpecies
      .replaceAll('_', ' ')
      .split(' ')
      .map((w) => w.isEmpty ? w : '${w[0].toUpperCase()}${w.substring(1)}')
      .join(' ');

  @override
  Widget build(BuildContext context) => SingleChildScrollView(
    padding: const EdgeInsets.fromLTRB(20,20,20,40),
    child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      Row(children: [
        IconButton(icon: const Icon(Icons.arrow_back_rounded, color: T.textSec),
            onPressed: onReset),
        Text('Result', style: T.theme.textTheme.titleLarge),
      ]),
      const SizedBox(height: 16),
      ClipRRect(borderRadius: BorderRadius.circular(16),
        child: Image.file(File(imagePath),
            width: double.infinity, height: 240, fit: BoxFit.cover)),
      const SizedBox(height: 16),
      _Card(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Icon(Icons.bug_report_rounded, color: _confColor, size: 18),
          const SizedBox(width: 8),
          Text('Identified Pest', style: T.theme.textTheme.bodyMedium),
        ]),
        const SizedBox(height: 8),
        Text(
          ['NO_DETECTION','LOW_CONF'].contains(result.predSpecies)
              ? 'Not identified' : _display,
          style: T.theme.textTheme.displayLarge),
        const SizedBox(height: 4),
        Text('Bucket: ${result.predBucket.replaceAll("_", " ")}',
            style: T.theme.textTheme.bodySmall),
      ])),
      const SizedBox(height: 12),
      _Card(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('Confidence', style: T.theme.textTheme.titleMedium),
        const SizedBox(height: 14),
        _Bar('Detection (YOLO)',       result.yoloConf, T.accent),
        const SizedBox(height: 10),
        _Bar('Classification (RN-18)', result.clfConf,  const Color(0xFF5AC8FA)),
        const SizedBox(height: 10),
        _Bar('Joint Score',            result.joint,    _confColor),
      ])),
      const SizedBox(height: 12),
      _Card(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('Pipeline Diagnostics', style: T.theme.textTheme.titleMedium),
        const SizedBox(height: 10),
        _Row('Decision Mode',  result.decisionMode),
        _Row('Boxes Detected', '${result.allBoxes.length}'),
        if (result.allBoxes.isNotEmpty)
          _Row('Top Conf', result.allBoxes.first.conf.toStringAsFixed(3)),
      ])),
      const SizedBox(height: 24),
      _PrimaryBtn(icon: Icons.camera_alt_rounded,
          label: 'Scan Another', onTap: onReset),
    ]),
  );
}

// ─── Camera page ─────────────────────────────────────────────────────────────

class CameraCapturePage extends StatefulWidget {
  final List<CameraDescription> cameras;
  const CameraCapturePage({super.key, required this.cameras});
  @override
  State<CameraCapturePage> createState() => _CameraState();
}

class _CameraState extends State<CameraCapturePage> {
  late CameraController _ctrl;
  bool _ready = false, _busy = false;

  @override
  void initState() {
    super.initState();
    _ctrl = CameraController(widget.cameras.first,
        ResolutionPreset.high, enableAudio: false);
    _ctrl.initialize().then((_) { if (mounted) setState(() => _ready = true); });
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  Future<void> _shoot() async {
    if (_busy || !_ctrl.value.isInitialized) return;
    setState(() => _busy = true);
    try {
      final f = await _ctrl.takePicture();
      if (mounted) Navigator.pop(context, f.path);
    } catch (_) { setState(() => _busy = false); }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: Colors.black,
    body: _ready ? Stack(children: [
      Positioned.fill(child: CameraPreview(_ctrl)),
      Positioned.fill(child: CustomPaint(painter: _FramePainter())),
      Positioned(bottom: 48, left: 0, right: 0,
        child: Center(child: GestureDetector(onTap: _shoot,
          child: Container(width: 72, height: 72,
            decoration: BoxDecoration(shape: BoxShape.circle, color: T.accent,
              boxShadow: [BoxShadow(color: T.accent.withAlpha(100),
                  blurRadius: 20, spreadRadius: 4)]),
            child: _busy
                ? const CircularProgressIndicator(color: T.bg, strokeWidth: 3)
                : const Icon(Icons.camera_alt_rounded, color: T.bg, size: 32))))),
      Positioned(top: 48, left: 16,
        child: SafeArea(child: IconButton(
          icon: const Icon(Icons.close_rounded, color: Colors.white, size: 28),
          onPressed: () => Navigator.pop(context)))),
    ]) : const Center(child: CircularProgressIndicator(color: T.accent)),
  );
}

// ─── Settings page ────────────────────────────────────────────────────────────

class SettingsPage extends ConsumerStatefulWidget {
  const SettingsPage({super.key});
  @override
  ConsumerState<SettingsPage> createState() => _SettingsState();
}

class _SettingsState extends ConsumerState<SettingsPage> {
  double _ft = 0.6, _lc = 0.4;
  bool _rescue = true, _pts = true;
  String _mode = 'hybrid';

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(backgroundColor: T.surface, elevation: 0,
        title: Text('Settings', style: T.theme.textTheme.titleLarge),
        iconTheme: const IconThemeData(color: T.textPri)),
    body: ListView(padding: const EdgeInsets.all(20), children: [
      _Section('Detection', [
        _Slider('Fusion Threshold', _ft, 0.3, 0.9,
            'Below this: fusion over top-K instead of TOP1.',
            (v) => setState(() => _ft = v)),
        _Slider('Low-Conf Floor', _lc, 0.1, 0.7,
            'Detections below this are rescued or discarded.',
            (v) => setState(() => _lc = v)),
      ]),
      const SizedBox(height: 20),
      _Section('SAM Mode', [
        _Switch('Use Point Prompts', 'Adds centre + corner points for better masks.',
            _pts, (v) => setState(() => _pts = v)),
        Padding(padding: const EdgeInsets.fromLTRB(16,8,16,12),
          child: SegmentedButton<String>(
            segments: const [
              ButtonSegment(value: 'box',    label: Text('Box')),
              ButtonSegment(value: 'mask',   label: Text('Mask')),
              ButtonSegment(value: 'hybrid', label: Text('Hybrid')),
            ],
            selected: {_mode},
            onSelectionChanged: (s) => setState(() => _mode = s.first),
          )),
      ]),
      const SizedBox(height: 20),
      _Section('Rescue', [
        _Switch('Low-Conf Rescue',
            'Run classifier on weak detections before discarding.',
            _rescue, (v) => setState(() => _rescue = v)),
      ]),
      const SizedBox(height: 32),
      _PrimaryBtn(icon: Icons.save_rounded, label: 'Save',
          onTap: () => Navigator.pop(context)),
    ]),
  );
}

// ─── Reusable widgets ─────────────────────────────────────────────────────────

class _Card extends StatelessWidget {
  final Widget child;
  const _Card({required this.child});
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(color: T.elevated,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: T.border)),
    child: child);
}

class _Bar extends StatelessWidget {
  final String label; final double value; final Color color;
  const _Bar(this.label, this.value, this.color);
  @override
  Widget build(BuildContext context) => Column(
    crossAxisAlignment: CrossAxisAlignment.start, children: [
    Row(children: [
      Text(label, style: T.theme.textTheme.bodySmall),
      const Spacer(),
      Text('${(value*100).toStringAsFixed(1)}%',
          style: T.theme.textTheme.bodySmall!.copyWith(
              color: color, fontWeight: FontWeight.w600)),
    ]),
    const SizedBox(height: 5),
    ClipRRect(borderRadius: BorderRadius.circular(4),
      child: LinearProgressIndicator(value: value.clamp(0,1),
          backgroundColor: T.border,
          valueColor: AlwaysStoppedAnimation(color), minHeight: 8)),
  ]);
}

class _Row extends StatelessWidget {
  final String label, value;
  const _Row(this.label, this.value);
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 4),
    child: Row(children: [
      Text(label, style: T.theme.textTheme.bodySmall), const Spacer(),
      Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
        decoration: BoxDecoration(color: T.surface,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: T.border)),
        child: Text(value, style: T.theme.textTheme.bodySmall!.copyWith(
            color: T.accent, fontWeight: FontWeight.w600, fontSize: 11))),
    ]));
}

class _PrimaryBtn extends StatelessWidget {
  final IconData icon; final String label; final VoidCallback onTap;
  const _PrimaryBtn({required this.icon, required this.label, required this.onTap});
  @override
  Widget build(BuildContext context) => ElevatedButton.icon(
    style: ElevatedButton.styleFrom(backgroundColor: T.accent,
        foregroundColor: T.bg, padding: const EdgeInsets.symmetric(vertical: 16),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        elevation: 0),
    icon: Icon(icon, size: 20), label: Text(label), onPressed: onTap);
}

class _SecondaryBtn extends StatelessWidget {
  final IconData icon; final String label; final VoidCallback onTap;
  const _SecondaryBtn({required this.icon, required this.label, required this.onTap});
  @override
  Widget build(BuildContext context) => OutlinedButton.icon(
    style: OutlinedButton.styleFrom(foregroundColor: T.accent,
        side: const BorderSide(color: T.accentDim),
        padding: const EdgeInsets.symmetric(vertical: 16),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
    icon: Icon(icon, size: 20), label: Text(label), onPressed: onTap);
}

class _Dot extends StatelessWidget {
  final AnimationController controller;
  const _Dot({required this.controller});
  @override
  Widget build(BuildContext context) => AnimatedBuilder(
    animation: controller, builder: (_, __) => Container(width: 10, height: 10,
      decoration: BoxDecoration(shape: BoxShape.circle,
        color: Color.lerp(T.accentDim, T.accent, controller.value),
        boxShadow: [BoxShadow(color: T.accent.withAlpha((100*controller.value).toInt()),
            blurRadius: 8)])));
}

class _Section extends StatelessWidget {
  final String title; final List<Widget> children;
  const _Section(this.title, this.children);
  @override
  Widget build(BuildContext context) => Column(
    crossAxisAlignment: CrossAxisAlignment.start, children: [
    Padding(padding: const EdgeInsets.only(bottom: 10),
      child: Text(title.toUpperCase(), style: T.theme.textTheme.bodySmall!.copyWith(
          letterSpacing: 1.2, color: T.accentDim, fontWeight: FontWeight.w700))),
    Container(decoration: BoxDecoration(color: T.elevated,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: T.border)),
        child: Column(children: children)),
  ]);
}

class _Slider extends StatelessWidget {
  final String label, hint; final double value, min, max;
  final ValueChanged<double> onChanged;
  const _Slider(this.label, this.value, this.min, this.max, this.hint, this.onChanged);
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.fromLTRB(16,12,16,4),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [
        Text(label, style: T.theme.textTheme.titleMedium), const Spacer(),
        Text(value.toStringAsFixed(2),
            style: T.theme.textTheme.titleMedium!.copyWith(color: T.accent)),
      ]),
      Slider(value: value, min: min, max: max,
          divisions: ((max-min)*20).round(),
          activeColor: T.accent, inactiveColor: T.border, onChanged: onChanged),
      Text(hint, style: T.theme.textTheme.bodySmall),
      const SizedBox(height: 8),
    ]));
}

class _Switch extends StatelessWidget {
  final String label, subtitle; final bool value; final ValueChanged<bool> onChanged;
  const _Switch(this.label, this.subtitle, this.value, this.onChanged);
  @override
  Widget build(BuildContext context) => SwitchListTile(
    title: Text(label, style: T.theme.textTheme.titleMedium),
    subtitle: Text(subtitle, style: T.theme.textTheme.bodySmall),
    value: value, onChanged: onChanged, activeColor: T.accent);
}

// ─── Painters ─────────────────────────────────────────────────────────────────

class _RingPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final cx = size.width/2, cy = size.height/2;
    final r  = math.min(cx, cy) - 8;
    canvas.drawCircle(Offset(cx,cy), r,
        Paint()..color=T.accentDim.withAlpha(70)..style=PaintingStyle.stroke..strokeWidth=1.5);
    canvas.drawCircle(Offset(cx,cy), r*0.5,
        Paint()..color=T.accent.withAlpha(38)..style=PaintingStyle.fill);
    canvas.drawCircle(Offset(cx,cy), 6, Paint()..color=T.accent);
    final tk = Paint()..color=T.accent..style=PaintingStyle.stroke..strokeWidth=2.5
        ..strokeCap=StrokeCap.round;
    const o=20.0;
    // corners
    for (final (fx,fy) in [(cx-r,cy-r),(cx+r,cy-r),(cx+r,cy+r),(cx-r,cy+r)]) {
      final sx = fx < cx ? 1 : -1, sy = fy < cy ? 1 : -1;
      canvas.drawLine(Offset(fx,fy+sy*o), Offset(fx,fy), tk);
      canvas.drawLine(Offset(fx,fy), Offset(fx+sx*o,fy), tk);
    }
  }
  @override bool shouldRepaint(_) => false;
}

class _FramePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()..color=T.accent..style=PaintingStyle.stroke..strokeWidth=3
        ..strokeCap=StrokeCap.round;
    const m=60.0, cl=28.0;
    final l=m, r=size.width-m, t=size.height*0.15, b=size.height*0.85;
    canvas..drawLine(Offset(l,t+cl),Offset(l,t),p)..drawLine(Offset(l,t),Offset(l+cl,t),p)
          ..drawLine(Offset(r-cl,t),Offset(r,t),p)..drawLine(Offset(r,t),Offset(r,t+cl),p)
          ..drawLine(Offset(r,b-cl),Offset(r,b),p)..drawLine(Offset(r,b),Offset(r-cl,b),p)
          ..drawLine(Offset(l+cl,b),Offset(l,b),p)..drawLine(Offset(l,b),Offset(l,b-cl),p);
  }
  @override bool shouldRepaint(_) => false;
}
